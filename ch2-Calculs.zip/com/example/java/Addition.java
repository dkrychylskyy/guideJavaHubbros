package com.example.java;

public class Addition extends Calcul{
	public void calculer(int a, int b) {
		setResultat(a + b);
	}
}
