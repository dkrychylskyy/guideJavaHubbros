package com.example.java;

public class Soustraction extends Addition {
	public void calculer(int a, int b) {
		super.calculer(a, -b);
	}
}
