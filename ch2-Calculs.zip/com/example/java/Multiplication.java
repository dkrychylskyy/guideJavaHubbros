package com.example.java;

public class Multiplication extends Calcul {
	public void calculer(int a, int b) {
		setResultat(a * b);
	}
}
